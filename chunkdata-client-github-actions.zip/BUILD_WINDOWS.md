# Build on Windows (no global Gradle install)

## 1) Install Java 21
Install JDK 21 and make sure `java` works in Command Prompt:

```bat
java -version
```

## 2) Download the Gradle Wrapper JAR (one-time)
This project includes `gradlew.bat`, but the wrapper needs this file:

- Download: `gradle-9.2.1-wrapper.jar` from `https://services.gradle.org/distributions/`
- Save it to this exact path in the project:

```
gradle\wrapper\gradle-wrapper.jar
```

## 3) Build the mod
Open Command Prompt in this project folder (where `build.gradle` is) and run:

```bat
.\gradlew.bat build
```

## 4) Find the jar
After a successful build, your mod jar will be in:

```
build\libs\
```

Put that jar in your Minecraft client `mods` folder.

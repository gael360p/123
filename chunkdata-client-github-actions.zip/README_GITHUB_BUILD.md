# ChunkData Client Profiler (Fabric)

This is a client-side Fabric mod that tracks per-chunk ChunkData packet size and shows a small heatmap overlay.

## Controls
- Hold **H** to show the heatmap (top-right).
- `/chunkdata heatmap on|off|toggle`
- `/chunkdata heatmap abnormalonly on|off|toggle` (green-only mode: only ABNORMAL chunks show)
- `/chunkdata top [count]`
- `/chunkdata here`
- `/chunkdata clear`

## Getting a built JAR using GitHub Actions
1. Upload this repository to GitHub (or push it with git).
2. Go to **Actions** tab.
3. Run **Build Fabric mod** (or push to `main`).
4. Download the artifact named **chunkdata-client-jar**.
5. Put the `.jar` inside your Minecraft client `mods/` folder (with Fabric Loader + Fabric API installed).

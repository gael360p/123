package com.gael.chunkdata;

public final class ChunkDataConfig {
    private ChunkDataConfig() {}

    /** Master enable/disable. Even when enabled, overlay only draws while holding the key. */
    public static boolean HEATMAP_ENABLED = true;

    /** If true, only abnormal chunks are drawn (green-only mode). */
    public static boolean ABNORMAL_ONLY_MODE = false;

    /** Heatmap window radius around player chunk: (2R+1)x(2R+1) cells. */
    public static int HEATMAP_RADIUS = 6;

    /** Pixel size per chunk cell. */
    public static int CELL_SIZE = 5;

    /** Margin from screen edge. */
    public static int MARGIN = 8;

    /** Abnormal threshold: mean + (STD_MULT * stddev) computed in displayed window. */
    public static double STD_MULT = 2.0;

    /** Panel alpha. */
    public static int PANEL_ALPHA = 0x40;
}

package com.gael.chunkdata;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.ChunkPos;

import java.util.List;

public final class ChunkDataCommands {
    private ChunkDataCommands() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("chunkdata")

            .then(ClientCommandManager.literal("here")
                .executes(ctx -> {
                    var mc = MinecraftClient.getInstance();
                    if (mc.player == null) return 0;
                    ChunkPos pos = mc.player.getChunkPos();
                    long bytes = ChunkDataStore.get(ChunkPos.toLong(pos.x, pos.z));
                    ctx.getSource().sendFeedback(Text.literal(
                        "Chunk (" + pos.x + "," + pos.z + ") chunkDataBytes=" + ChunkDataStore.formatBytes(bytes) + "B"
                    ));
                    return 1;
                })
            )

            .then(ClientCommandManager.literal("top")
                .executes(ctx -> top(ctx.getSource(), 10))
                .then(ClientCommandManager.argument("count", IntegerArgumentType.integer(1, 50))
                    .executes(ctx -> top(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count")))
                )
            )

            .then(ClientCommandManager.literal("heatmap")
                .then(ClientCommandManager.literal("on").executes(ctx -> {
                    ChunkDataConfig.HEATMAP_ENABLED = true;
                    ctx.getSource().sendFeedback(Text.literal("Heatmap enabled (hold H to show)."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("off").executes(ctx -> {
                    ChunkDataConfig.HEATMAP_ENABLED = false;
                    ctx.getSource().sendFeedback(Text.literal("Heatmap disabled."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                    ChunkDataConfig.HEATMAP_ENABLED = !ChunkDataConfig.HEATMAP_ENABLED;
                    ctx.getSource().sendFeedback(Text.literal(
                        "Heatmap " + (ChunkDataConfig.HEATMAP_ENABLED ? "enabled" : "disabled") + " (hold H to show)."
                    ));
                    return 1;
                }))
                .then(ClientCommandManager.literal("abnormalonly")
                    .then(ClientCommandManager.literal("on").executes(ctx -> {
                        ChunkDataConfig.ABNORMAL_ONLY_MODE = true;
                        ctx.getSource().sendFeedback(Text.literal("ABNORMAL-only mode ON (green-only). Hold H to show."));
                        return 1;
                    }))
                    .then(ClientCommandManager.literal("off").executes(ctx -> {
                        ChunkDataConfig.ABNORMAL_ONLY_MODE = false;
                        ctx.getSource().sendFeedback(Text.literal("ABNORMAL-only mode OFF."));
                        return 1;
                    }))
                    .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                        ChunkDataConfig.ABNORMAL_ONLY_MODE = !ChunkDataConfig.ABNORMAL_ONLY_MODE;
                        ctx.getSource().sendFeedback(Text.literal(
                            "ABNORMAL-only mode " + (ChunkDataConfig.ABNORMAL_ONLY_MODE ? "ON" : "OFF") + "."
                        ));
                        return 1;
                    }))
                )
            )

            .then(ClientCommandManager.literal("clear")
                .executes(ctx -> {
                    ChunkDataStore.clear();
                    ctx.getSource().sendFeedback(Text.literal("Cleared stored results."));
                    return 1;
                })
            )
        );
    }

    private static int top(FabricClientCommandSource source, int count) {
        var mc = MinecraftClient.getInstance();
        ChunkPos center = (mc.player != null) ? mc.player.getChunkPos() : new ChunkPos(0, 0);

        var stats = ChunkDataAnalyzer.statsForArea(center, ChunkDataConfig.HEATMAP_RADIUS);

        List<ChunkDataStore.Row> rows = ChunkDataStore.top(count);
        source.sendFeedback(Text.literal(
            "Top " + rows.size() + " chunks by ChunkData packet payload size. " +
            "ABNORMAL = > mean + " + ChunkDataConfig.STD_MULT + "σ (window samples=" + stats.samples() + ")."
        ));

        for (int i = 0; i < rows.size(); i++) {
            var r = rows.get(i);
            int x = ChunkDataStore.packedX(r.pos());
            int z = ChunkDataStore.packedZ(r.pos());

            boolean abnormal = ChunkDataAnalyzer.isAbnormal(r.bytes(), stats);

            Text line = Text.literal(
                (i + 1) + ") (" + x + "," + z + ") = " + ChunkDataStore.formatBytes(r.bytes()) + "B" +
                (abnormal ? "  [ABNORMAL]" : "")
            );
            if (abnormal) line = line.copy().formatted(Formatting.GREEN);

            source.sendFeedback(line);
        }

        return 1;
    }
}
